"use client";

import { useEffect, useMemo, useState, type FormEvent } from "react";

type IconName =
  | "arrow-right"
  | "arrow-up-right"
  | "book"
  | "cart"
  | "check"
  | "check-circle"
  | "chevron-right"
  | "clock"
  | "close"
  | "compass"
  | "external"
  | "globe"
  | "layers"
  | "mail"
  | "map"
  | "menu"
  | "moon"
  | "mountain"
  | "phone"
  | "pin"
  | "play"
  | "search"
  | "send"
  | "shield"
  | "sparkles"
  | "sun"
  | "target"
  | "users";

type CourseKind = "Full course" | "Mini course" | "PYQ series" | "Free resource";
type Track = "UGC NET" | "UPSC CSE" | "State SET" | "Free";

type Course = {
  id: string;
  title: string;
  kind: CourseKind;
  track: Track;
  subject: string;
  image: string;
  badge: string;
  summary: string;
  duration: string;
  lessons: string;
  highlights: string[];
};

type Offer = {
  id: string;
  title: string;
  eyebrow: string;
  description: string;
  icon: IconName;
  accent: string;
  courseIds: string[];
  examFocus: string;
};

type ModalState =
  | { type: "course"; course: Course }
  | { type: "offer"; offer: Offer }
  | { type: "plan" }
  | null;

type FormValues = {
  name: string;
  email: string;
  phone: string;
  examFocus: string;
  message: string;
  website: string;
};

const courses: Course[] = [
  {
    id: "net-geography",
    title: "UGC NET Geography — Complete Course",
    kind: "Full course",
    track: "UGC NET",
    subject: "Geography · Paper II",
    image: "/images/free-geography-hero.jpg",
    badge: "Complete pathway",
    summary: "A structured route through physical, human, Indian and regional geography—built to move from clear concepts to confident exam practice.",
    duration: "Self-paced",
    lessons: "Concepts · maps · revision",
    highlights: ["Physical and human geography, explained in sequence", "Indian geography with map-led revision", "Topic checks and exam-focused practice"],
  },
  {
    id: "upsc-optional",
    title: "UPSC Geography Optional",
    kind: "Full course",
    track: "UPSC CSE",
    subject: "Civil Services · Optional",
    image: "/images/free-fieldwork.jpg",
    badge: "Mains focused",
    summary: "Connect geographical ideas to the optional syllabus with a steady programme for conceptual depth, diagrams and answer practice.",
    duration: "Self-paced",
    lessons: "Syllabus · diagrams · answers",
    highlights: ["A paper-by-paper syllabus roadmap", "Diagram and map work made part of revision", "Practice prompts for structured answers"],
  },
  {
    id: "net-pyq",
    title: "UGC NET Geography PYQs",
    kind: "PYQ series",
    track: "UGC NET",
    subject: "Geography · Topic-wise questions",
    image: "/images/free-map-study.jpg",
    badge: "Section-wise practice",
    summary: "Work through previous questions by geography topic. Spot recurring ideas, check your understanding and make each revision session count.",
    duration: "Study anytime",
    lessons: "Topic-wise · answer review",
    highlights: ["Questions grouped around syllabus themes", "A practical way to revise between lessons", "Designed to support—not replace—concept learning"],
  },
  {
    id: "upsc-pyq",
    title: "UPSC Geography Optional PYQs",
    kind: "PYQ series",
    track: "UPSC CSE",
    subject: "Civil Services · Previous papers",
    image: "/images/free-fieldwork.jpg",
    badge: "Past-paper practice",
    summary: "Use previous questions to understand what a well-prepared geography answer needs, from selection of examples to map and diagram practice.",
    duration: "Study anytime",
    lessons: "Paper I · Paper II",
    highlights: ["Previous questions organised for targeted practice", "A useful companion to an answer-writing routine", "Revisit themes across physical and human geography"],
  },
  {
    id: "climatology",
    title: "Climatology & Oceanography",
    kind: "Mini course",
    track: "UGC NET",
    subject: "Atmosphere · Oceans",
    image: "/images/free-geography-hero.jpg",
    badge: "Popular topic",
    summary: "Make sense of the processes behind weather, climate and ocean circulation, then connect those processes to geography exam questions.",
    duration: "Self-paced",
    lessons: "Concept notes · recap",
    highlights: ["Atmospheric circulation and weather systems", "Climate classifications and change", "Ocean currents, waves and the wider system"],
  },
  {
    id: "geomorphology",
    title: "Geomorphology & Geographical Thought",
    kind: "Mini course",
    track: "UGC NET",
    subject: "Landforms · Ideas",
    image: "/images/free-map-study.jpg",
    badge: "Clear concepts",
    summary: "Build a connected understanding of landform development alongside the ideas and schools that have shaped geographical thought.",
    duration: "Self-paced",
    lessons: "Core ideas · topic recap",
    highlights: ["Earth processes and landscape evolution", "Key concepts in geographical thought", "Short recaps to make revision easier"],
  },
  {
    id: "indian-geography",
    title: "Indian Geography: People & Places",
    kind: "Mini course",
    track: "State SET",
    subject: "India · Regional geography",
    image: "/images/free-fieldwork.jpg",
    badge: "Map-led learning",
    summary: "Explore India’s physical and human geography through regions, resources, settlement patterns and the maps that bring them together.",
    duration: "Self-paced",
    lessons: "Regions · resources · maps",
    highlights: ["The physical framework of India", "Population, settlement and resources", "Use maps to connect place with process"],
  },
  {
    id: "human-geography",
    title: "Human & Economic Geography",
    kind: "Mini course",
    track: "UGC NET",
    subject: "Population · Development",
    image: "/images/free-map-study.jpg",
    badge: "Build your toolkit",
    summary: "Understand how people, economies and places shape one another with a compact course for focused geography revision.",
    duration: "Self-paced",
    lessons: "Themes · examples · recap",
    highlights: ["Population and settlement patterns", "Economic activity and regional change", "Examples that help link theory to place"],
  },
  {
    id: "map-skills",
    title: "Map Skills: A Free Introduction",
    kind: "Free resource",
    track: "Free",
    subject: "Maps · Scale · Spatial thinking",
    image: "/images/free-map-study.jpg",
    badge: "Start learning free",
    summary: "Start with the essentials: how to read a map, understand scale and use spatial clues to make geographical concepts easier to picture.",
    duration: "Short lessons",
    lessons: "Beginner friendly",
    highlights: ["Orientation, symbols and scale", "Read patterns and connections on a map", "A practical first step for geography learners"],
  },
  {
    id: "paper-one-starter",
    title: "Paper I Study Skills Starter",
    kind: "Free resource",
    track: "Free",
    subject: "Study planning · Exam habits",
    image: "/images/free-geography-hero.jpg",
    badge: "Free starter series",
    summary: "A small, practical set of prompts for planning revision, building recall and making time for steady question practice.",
    duration: "Short lessons",
    lessons: "Study at your pace",
    highlights: ["Break revision into manageable sessions", "Use active recall with your own notes", "Make space for a little question practice each week"],
  },
  {
    id: "atlas-starter",
    title: "How to Read an Atlas",
    kind: "Free resource",
    track: "Free",
    subject: "Atlas reading · Place knowledge",
    image: "/images/free-fieldwork.jpg",
    badge: "A free map-room lesson",
    summary: "Get comfortable moving between scale, symbols and place names, and find a simple way to bring an atlas into your regular study routine.",
    duration: "Short lessons",
    lessons: "No prior experience needed",
    highlights: ["Choose the right map for the question", "Use the index, legend and scale", "Connect map patterns with what you are learning"],
  },
];

const offers: Offer[] = [
  {
    id: "net-route",
    title: "The NET Geography Route",
    eyebrow: "A study path",
    description: "Pair the complete geography course with topic-wise previous questions for a clear learn–revise–practice routine.",
    icon: "compass",
    accent: "sea",
    courseIds: ["net-geography", "net-pyq"],
    examFocus: "UGC NET Geography",
  },
  {
    id: "upsc-route",
    title: "UPSC Optional, in Sequence",
    eyebrow: "A study path",
    description: "Bring concept learning and past-paper practice together as you work through the Geography Optional syllabus.",
    icon: "layers",
    accent: "sand",
    courseIds: ["upsc-optional", "upsc-pyq"],
    examFocus: "UPSC CSE — Geography Optional",
  },
  {
    id: "geo-foundations",
    title: "Geography Foundations Pack",
    eyebrow: "Start with the essentials",
    description: "Explore a small set of core topic courses and make the concepts, maps and processes behind geography feel more connected.",
    icon: "globe",
    accent: "clay",
    courseIds: ["climatology", "geomorphology", "indian-geography"],
    examFocus: "Geography course enquiry",
  },
];

const trackFilters = ["All courses", "UGC NET", "UPSC CSE", "State SET", "Free"] as const;

function Icon({ name, size = 20, className = "" }: { name: IconName; size?: number; className?: string }) {
  let artwork;

  switch (name) {
    case "arrow-right":
      artwork = <><path d="M5 12h14" /><path d="m12 5 7 7-7 7" /></>;
      break;
    case "arrow-up-right":
      artwork = <><path d="M7 17 17 7" /><path d="M7 7h10v10" /></>;
      break;
    case "book":
      artwork = <><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" /><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z" /><path d="M8 7h8M8 11h7" /></>;
      break;
    case "cart":
      artwork = <><circle cx="9" cy="20" r="1" /><circle cx="18" cy="20" r="1" /><path d="M2 3h2l2.2 11.1a2 2 0 0 0 2 1.6h9.6a2 2 0 0 0 1.9-1.4L22 8H5" /></>;
      break;
    case "check":
      artwork = <path d="m5 12 4 4L19 6" />;
      break;
    case "check-circle":
      artwork = <><circle cx="12" cy="12" r="9.2" /><path d="m8 12 2.6 2.6L16.5 9" /></>;
      break;
    case "chevron-right":
      artwork = <path d="m9 18 6-6-6-6" />;
      break;
    case "clock":
      artwork = <><circle cx="12" cy="12" r="9.5" /><path d="M12 7v5l3 2" /></>;
      break;
    case "close":
      artwork = <><path d="m18 6-12 12M6 6l12 12" /></>;
      break;
    case "compass":
      artwork = <><circle cx="12" cy="12" r="9.5" /><path d="m15.8 8.2-2.4 5.2-5.2 2.4 2.4-5.2 5.2-2.4Z" /><circle cx="12" cy="12" r="1" /></>;
      break;
    case "external":
      artwork = <><path d="M14 3h7v7" /><path d="m10 14 11-11" /><path d="M19 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h6" /></>;
      break;
    case "globe":
      artwork = <><circle cx="12" cy="12" r="9.5" /><path d="M2.5 12h19M12 2.5c2.2 2.6 3.3 5.8 3.3 9.5s-1.1 6.9-3.3 9.5c-2.2-2.6-3.3-5.8-3.3-9.5S9.8 5.1 12 2.5Z" /></>;
      break;
    case "layers":
      artwork = <><path d="m12 3 9 5-9 5-9-5 9-5Z" /><path d="m3 12 9 5 9-5M3 16l9 5 9-5" /></>;
      break;
    case "mail":
      artwork = <><rect x="3" y="5" width="18" height="14" rx="2" /><path d="m3 7 9 6 9-6" /></>;
      break;
    case "map":
      artwork = <><path d="m3 6 6-3 6 3 6-3v15l-6 3-6-3-6 3V6Z" /><path d="M9 3v15M15 6v15" /></>;
      break;
    case "menu":
      artwork = <><path d="M4 7h16M4 12h16M4 17h16" /></>;
      break;
    case "moon":
      artwork = <path d="M20.8 14A8.6 8.6 0 0 1 10 3.2 8.8 8.8 0 1 0 20.8 14Z" />;
      break;
    case "mountain":
      artwork = <><path d="m3 19 6.3-11 3.3 5.4 2.4-3.8L21 19H3Z" /><path d="m7.4 11.3 1.8 1.3 1.9-.7M14.9 11.3l1.1 1 1.4-.5" /></>;
      break;
    case "phone":
      artwork = <><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.3 19.3 0 0 1-6-6 19.8 19.8 0 0 1-3.1-8.7A2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1.2.4 2.3.8 3.3a2 2 0 0 1-.4 2.1L8.2 10.3a16 16 0 0 0 6 6l1.2-1.3a2 2 0 0 1 2.1-.4c1.1.4 2.2.7 3.3.8a2 2 0 0 1 1.2 1.5Z" /></>;
      break;
    case "pin":
      artwork = <><path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z" /><circle cx="12" cy="10" r="2.5" /></>;
      break;
    case "play":
      artwork = <><path d="m8 5 11 7-11 7V5Z" /></>;
      break;
    case "search":
      artwork = <><circle cx="10.8" cy="10.8" r="7.3" /><path d="m16.2 16.2 4.5 4.5" /></>;
      break;
    case "send":
      artwork = <><path d="m22 2-7 20-4-9-9-4 20-7Z" /><path d="M22 2 11 13" /></>;
      break;
    case "shield":
      artwork = <><path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11Z" /><path d="m9 12 2 2 4-4" /></>;
      break;
    case "sparkles":
      artwork = <><path d="m12 3 1.9 5.8L20 11l-6.1 2.2L12 19l-1.9-5.8L4 11l6.1-2.2L12 3Z" /><path d="m19 14 1.1 2.9L23 18l-2.9 1.1L19 22l-1.1-2.9L15 18l2.9-1.1L19 14ZM5 2l.9 2.1L8 5l-2.1.9L5 8l-.9-2.1L2 5l2.1-.9L5 2Z" /></>;
      break;
    case "sun":
      artwork = <><circle cx="12" cy="12" r="4" /><path d="M12 2v2m0 16v2M4.9 4.9l1.4 1.4m11.4 11.4 1.4 1.4M2 12h2m16 0h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" /></>;
      break;
    case "target":
      artwork = <><circle cx="12" cy="12" r="9.5" /><circle cx="12" cy="12" r="5.5" /><circle cx="12" cy="12" r="1.5" /></>;
      break;
    case "users":
      artwork = <><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M22 21v-2a4 4 0 0 0-3-3.9M16 3.2a4 4 0 0 1 0 7.7" /></>;
      break;
    default:
      artwork = <circle cx="12" cy="12" r="9" />;
  }

  return (
    <svg
      aria-hidden="true"
      className={className}
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.65"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {artwork}
    </svg>
  );
}

function BrandMark({ inverse = false }: { inverse?: boolean }) {
  return (
    <a className={`brand-mark${inverse ? " brand-mark--inverse" : ""}`} href="#hero" aria-label="FREE Geography home">
      <span className="brand-mark__symbol" aria-hidden="true">
        <svg viewBox="0 0 44 44" fill="none">
          <circle cx="22" cy="22" r="19.5" stroke="currentColor" strokeWidth="1.2" />
          <circle cx="22" cy="22" r="15.3" stroke="currentColor" strokeWidth=".7" strokeDasharray="1.4 2.4" />
          <path d="M22 6.4v31.2M6.4 22h31.2" stroke="currentColor" strokeWidth=".8" />
          <path d="m25.8 14.1-3.7 8-8 3.7 3.7-8 8-3.7Z" fill="currentColor" />
          <circle cx="22" cy="22" r="1.4" fill="var(--page-bg, #fbfaf6)" />
        </svg>
      </span>
      <span className="brand-mark__wording">
        <span className="brand-mark__name">FREE<span>.</span></span>
        <span className="brand-mark__descriptor">GEOGRAPHY</span>
      </span>
    </a>
  );
}

const emptyForm: FormValues = {
  name: "",
  email: "",
  phone: "",
  examFocus: "",
  message: "",
  website: "",
};

export default function HomeExperience() {
  const [selectedTrack, setSelectedTrack] = useState<(typeof trackFilters)[number]>("All courses");
  const [searchTerm, setSearchTerm] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const [learningPlan, setLearningPlan] = useState<string[]>([]);
  const [modal, setModal] = useState<ModalState>(null);
  const [notice, setNotice] = useState("");
  const [formValues, setFormValues] = useState<FormValues>(emptyForm);
  const [formState, setFormState] = useState<"idle" | "sending" | "success" | "error">("idle");
  const [formNotice, setFormNotice] = useState("");

  const filteredCourses = useMemo(() => {
    const search = searchTerm.trim().toLocaleLowerCase();
    return courses.filter((course) => {
      const matchesTrack = selectedTrack === "All courses" || course.track === selectedTrack;
      const searchable = `${course.title} ${course.subject} ${course.summary} ${course.track} ${course.kind}`.toLocaleLowerCase();
      return matchesTrack && (!search || searchable.includes(search));
    });
  }, [searchTerm, selectedTrack]);

  const plannedCourses = courses.filter((course) => learningPlan.includes(course.id));
  const courseCount = filteredCourses.length;

  useEffect(() => {
    if (!notice) return;
    const timer = window.setTimeout(() => setNotice(""), 3200);
    return () => window.clearTimeout(timer);
  }, [notice]);

  useEffect(() => {
    if (!modal) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setModal(null);
    };
    window.addEventListener("keydown", handleEscape);
    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", handleEscape);
    };
  }, [modal]);

  function flash(message: string) {
    setNotice(message);
  }

  function addToPlan(id: string) {
    const course = courses.find((item) => item.id === id);
    setLearningPlan((current) => (current.includes(id) ? current : [...current, id]));
    flash(course ? `Added “${course.title}” to your study plan.` : "Added to your study plan.");
  }

  function addOfferToPlan(offer: Offer) {
    setLearningPlan((current) => Array.from(new Set([...current, ...offer.courseIds])));
    setModal({ type: "plan" });
    flash("Study path added to your plan.");
  }

  function removeFromPlan(id: string) {
    setLearningPlan((current) => current.filter((item) => item !== id));
  }

  function updateForm(key: keyof FormValues, value: string) {
    setFormValues((current) => ({ ...current, [key]: value }));
    if (formState !== "idle") {
      setFormState("idle");
      setFormNotice("");
    }
  }

  function startEnquiry(examFocus: string) {
    setFormValues((current) => ({ ...current, examFocus }));
    setModal(null);
    setMenuOpen(false);
    window.setTimeout(() => document.getElementById("contact")?.scrollIntoView({ behavior: "smooth", block: "start" }), 60);
  }

  function handleSearch(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSelectedTrack("All courses");
    document.getElementById("course-catalog")?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  async function handleInquirySubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setFormState("sending");
    setFormNotice("");

    try {
      const response = await fetch("/api/inquiries", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formValues),
      });
      const result = (await response.json()) as { error?: string; message?: string };
      if (!response.ok) throw new Error(result.error || "We could not send your enquiry. Please try again.");
      setFormState("success");
      setFormNotice(result.message || "Thanks for writing. Your enquiry has been received.");
      setFormValues(emptyForm);
    } catch (error) {
      setFormState("error");
      setFormNotice(error instanceof Error ? error.message : "Something went wrong. Please try again.");
    }
  }

  function closeMenu() {
    setMenuOpen(false);
  }

  function renderCourseCards(kind: CourseKind) {
    const results = filteredCourses.filter((course) => course.kind === kind);
    if (results.length === 0) return null;

    return (
      <div className="course-grid">
        {results.map((course, index) => (
          <article key={course.id} className={`course-card course-card--${index % 3}`}>
            <button
              className="course-card__cover"
              style={{ backgroundImage: `url("${course.image}")` }}
              type="button"
              onClick={() => setModal({ type: "course", course })}
              aria-label={`Explore ${course.title}`}
            >
              <span className="course-card__pill">{course.badge}</span>
              <span className="course-card__play" aria-hidden="true"><Icon name={course.kind === "Free resource" ? "play" : "arrow-up-right"} size={19} /></span>
              <span className="course-card__image-title">{course.kind === "Free resource" ? "OPEN CLASSROOM" : course.track.toUpperCase()}</span>
            </button>
            <div className="course-card__content">
              <div className="course-card__meta">
                <span><Icon name={course.kind === "PYQ series" ? "layers" : course.kind === "Free resource" ? "play" : "book"} size={14} /> {course.kind}</span>
                <span className="course-card__duration"><Icon name="clock" size={14} /> {course.duration}</span>
              </div>
              <p className="course-card__subject">{course.subject}</p>
              <h3>{course.title}</h3>
              <p className="course-card__summary">{course.summary}</p>
              <div className="course-card__footer">
                <span className="course-card__lessons">{course.lessons}</span>
                <button className="text-link" type="button" onClick={() => setModal({ type: "course", course })}>
                  View details <Icon name="arrow-up-right" size={16} />
                </button>
              </div>
            </div>
          </article>
        ))}
      </div>
    );
  }

  return (
    <div className={`site-shell${darkMode ? " theme-dark" : ""}`}>
      <div className="announcement-bar">
        <div className="site-container announcement-bar__inner">
          <span className="announcement-bar__message"><Icon name="sparkles" size={15} /> Every geography lesson, free to explore</span>
          <a href="#free-courses" className="announcement-bar__link" onClick={closeMenu}>Explore free lessons <Icon name="arrow-right" size={14} /></a>
        </div>
      </div>

      <header className="site-header">
        <div className="site-container header-inner">
          <BrandMark />
          <nav id="mobile-navigation" className={`primary-nav${menuOpen ? " primary-nav--open" : ""}`} aria-label="Main navigation">
            <a href="#hero" onClick={closeMenu}>Home</a>
            <a href="#pyqs" onClick={closeMenu}>PYQs</a>
            <a href="#full-courses" onClick={closeMenu}>Full Course</a>
            <a href="#mini-courses" onClick={closeMenu}>Mini Courses</a>
            <a href="#free-courses" onClick={closeMenu}>Free Content</a>
            <a href="#contact" onClick={closeMenu}>Contact</a>
          </nav>
          <div className="header-actions">
            <button className="theme-toggle" type="button" onClick={() => setDarkMode((current) => !current)} aria-label={darkMode ? "Switch to light theme" : "Switch to dark theme"} title={darkMode ? "Switch to light theme" : "Switch to dark theme"}>
              <Icon name={darkMode ? "sun" : "moon"} size={19} />
            </button>
            <button className="plan-button" type="button" onClick={() => setModal({ type: "plan" })} aria-label={`Open study plan with ${learningPlan.length} courses`}>
              <Icon name="cart" size={17} /><span>My plan</span><span className="plan-button__count">{learningPlan.length}</span>
            </button>
            <button className="menu-toggle" type="button" onClick={() => setMenuOpen((current) => !current)} aria-expanded={menuOpen} aria-controls="mobile-navigation" aria-label={menuOpen ? "Close navigation" : "Open navigation"}>
              <Icon name={menuOpen ? "close" : "menu"} size={23} />
            </button>
          </div>
        </div>
        <span className="sr-only" id="mobile-navigation">Use the navigation links above.</span>
      </header>

      <main>
        <section id="hero" className="hero-section">
          <div className="site-container hero-layout">
            <div className="hero-copy">
              <div className="eyebrow"><span className="eyebrow__dot" /> GEOGRAPHY, IN CONTEXT</div>
              <h1>Learn the <span>landscape.</span><br />Own your <span className="hero-heading__last">direction.</span></h1>
              <p className="hero-copy__lead">Clear concepts. A map-first mindset. Free courses, PYQs and map practice — with no paywalls, ever.</p>
              <div className="hero-copy__actions">
                <a className="button button--primary" href="#course-catalog">Explore courses <Icon name="arrow-right" size={18} /></a>
                <a className="button button--quiet" href="#free-courses">Start with a free lesson <Icon name="play" size={16} /></a>
              </div>
              <div className="hero-note"><span className="hero-note__icon"><Icon name="compass" size={20} /></span><span>For curious minds preparing for<br /><strong>UGC NET · UPSC · State SET</strong></span></div>
              <form className="hero-search" role="search" onSubmit={handleSearch}>
                <Icon name="search" size={19} />
                <input aria-label="Search geography courses" value={searchTerm} onChange={(event) => setSearchTerm(event.target.value)} placeholder="Find a topic, course or PYQ series" />
                {searchTerm && <button type="button" className="hero-search__clear" aria-label="Clear search" onClick={() => setSearchTerm("")}><Icon name="close" size={17} /></button>}
                <button type="submit" className="hero-search__submit" aria-label="Search courses"><Icon name="arrow-right" size={18} /></button>
              </form>
            </div>
            <div className="hero-visual-wrap">
              <div className="hero-visual" role="img" aria-label="Aerial view of layered Himalayan mountain ranges at sunrise" />
              <div className="hero-visual__label"><span className="hero-visual__pin"><Icon name="pin" size={17} /></span><span>READ THE WORLD<br /><strong>ONE PLACE AT A TIME</strong></span></div>
              <div className="hero-visual__caption"><span className="hero-visual__caption-rule" /><span>MAPS ARE STORIES OF PLACE.</span></div>
              <div className="hero-visual__seal" aria-hidden="true"><Icon name="compass" size={25} /><span>KNOW<br />YOUR<br />WORLD</span></div>
            </div>
          </div>
          <div className="hero-bottom site-container">
            <span className="hero-bottom__line" />
            <span>A thoughtful starting point for the next step in your geography journey.</span>
            <a href="#study-paths" aria-label="Scroll to study paths"><Icon name="arrow-right" size={17} /></a>
          </div>
        </section>

        <section className="value-strip" aria-label="What you can explore">
          <div className="site-container value-strip__grid">
            <div className="value-strip__intro"><span className="mini-label">FREE TO EXPLORE</span><strong>Your next chapter,<br />with a little more clarity.</strong></div>
            <div className="value-item"><span className="value-item__icon"><Icon name="book" size={19} /></span><span><strong>Structured courses</strong><small>Learn ideas in sequence</small></span></div>
            <div className="value-item"><span className="value-item__icon value-item__icon--amber"><Icon name="layers" size={19} /></span><span><strong>Section-wise PYQs</strong><small>Practice by topic</small></span></div>
            <div className="value-item"><span className="value-item__icon value-item__icon--coral"><Icon name="map" size={19} /></span><span><strong>Map-led learning</strong><small>Connect facts to place</small></span></div>
          </div>
        </section>

        <section id="study-paths" className="study-paths section-pad">
          <div className="site-container">
            <div className="section-heading section-heading--split">
              <div><span className="section-kicker">A GOOD PLACE TO START</span><h2>Choose a path.<br /><em>Find your bearings.</em></h2></div>
              <p>One well-planned route can make a big syllabus feel a little less like unknown territory. Find a combination that fits the way you like to learn.</p>
            </div>
            <div className="offer-grid">
              {offers.map((offer, index) => (
                <button key={offer.id} className={`offer-card offer-card--${offer.accent}`} type="button" onClick={() => setModal({ type: "offer", offer })}>
                  <span className="offer-card__top"><span className="offer-card__icon"><Icon name={offer.icon} size={21} /></span><span className="offer-card__number">0{index + 1}</span></span>
                  <span className="offer-card__eyebrow">{offer.eyebrow}</span>
                  <span className="offer-card__title">{offer.title}</span>
                  <span className="offer-card__description">{offer.description}</span>
                  <span className="offer-card__link">Explore this path <Icon name="arrow-up-right" size={17} /></span>
                </button>
              ))}
            </div>
            <p className="offer-note"><Icon name="shield" size={15} /> Every study path here is free to access. Not sure where to begin? Send us a note and we’ll help you find a starting point.</p>
          </div>
        </section>

        <section id="pyqs" className="pyq-section section-pad">
          <div className="site-container">
            <div className="section-heading section-heading--split">
              <div><span className="section-kicker">PRACTISE WITH PURPOSE</span><h2>Questions that<br /><em>bring it together.</em></h2></div>
              <div className="section-heading__aside"><p>Make previous questions part of how you learn—not only the last step before your exam.</p><a className="text-link text-link--dark" href="#course-catalog" onClick={() => { setSelectedTrack("All courses"); setSearchTerm("PYQ"); }}>Explore the PYQ library <Icon name="arrow-right" size={16} /></a></div>
            </div>
            <div className="pyq-grid">
              {filteredCourses.filter((course) => course.kind === "PYQ series").map((course, index) => (
                <article key={course.id} className={`pyq-card pyq-card--${index}`}>
                  <div className="pyq-card__image" style={{ backgroundImage: `url("${course.image}")` }} role="img" aria-label={`${course.track} geography study image`}>
                    <span className="pyq-card__badge"><Icon name="layers" size={14} /> TOPIC-WISE PRACTICE</span>
                    <span className="pyq-card__index">0{index + 1}</span>
                    <span className="pyq-card__mini-mark"><Icon name="map" size={23} /></span>
                  </div>
                  <div className="pyq-card__body">
                    <div className="pyq-card__heading"><div><span className="course-card__subject">{course.subject}</span><h3>{course.title}</h3></div><button type="button" onClick={() => setModal({ type: "course", course })} aria-label={`View ${course.title}`}><Icon name="arrow-up-right" size={19} /></button></div>
                    <p>{course.summary}</p>
                    <div className="pyq-card__footer"><span><Icon name="check-circle" size={15} /> Section-wise question practice</span><button type="button" className="text-link" onClick={() => setModal({ type: "course", course })}>See what’s inside <Icon name="arrow-right" size={15} /></button></div>
                  </div>
                </article>
              ))}
              {filteredCourses.filter((course) => course.kind === "PYQ series").length === 0 && <div className="empty-section">Try “All courses” or choose a different exam track to see PYQ series.</div>}
            </div>
          </div>
        </section>

        <section id="course-catalog" className="catalog-section section-pad">
          <div className="site-container">
            <div className="section-heading section-heading--split catalog-heading">
              <div><span className="section-kicker">THE FREE CLASSROOM</span><h2>Good learning is<br /><em>a journey, not a sprint.</em></h2></div>
              <p>Go deep with a full course, focus on a single topic, or start for free. Explore geography courses and question practice at your own pace.</p>
            </div>
            <div className="catalog-tools">
              <div className="catalog-tools__intro"><span>{courseCount} free {courseCount === 1 ? "resource" : "resources"} to explore</span><span className="catalog-tools__divider" /><span>{searchTerm ? `Showing results for “${searchTerm}”` : "Select a study track"}</span></div>
              <div className="filter-list" role="group" aria-label="Filter courses by exam">
                {trackFilters.map((track) => <button key={track} type="button" className={`filter-chip${selectedTrack === track ? " filter-chip--active" : ""}`} aria-pressed={selectedTrack === track} onClick={() => setSelectedTrack(track)}>{track}</button>)}
              </div>
            </div>

            {renderCourseCards("Full course") && <section id="full-courses" className="catalog-group">
              <div className="catalog-group__heading"><div><span className="mini-label">THE WHOLE PICTURE</span><h3>Full courses</h3></div><span className="catalog-group__aside">A complete route through your syllabus</span></div>
              {renderCourseCards("Full course")}
            </section>}
            {renderCourseCards("PYQ series") && <section className="catalog-group catalog-group--subtle">
              <div className="catalog-group__heading"><div><span className="mini-label">LEARN · RECALL · REPEAT</span><h3>Question practice</h3></div><a className="text-link" href="#pyqs">About our PYQ library <Icon name="arrow-right" size={15} /></a></div>
              {renderCourseCards("PYQ series")}
            </section>}
            {renderCourseCards("Mini course") && <section id="mini-courses" className="catalog-group">
              <div className="catalog-group__heading"><div><span className="mini-label">ONE TOPIC AT A TIME</span><h3>Mini courses</h3></div><span className="catalog-group__aside">Go deeper into the topics on your list</span></div>
              {renderCourseCards("Mini course")}
            </section>}
            {renderCourseCards("Free resource") && <section id="free-courses" className="catalog-group catalog-group--free">
              <div className="catalog-group__heading"><div><span className="mini-label">OPEN THE CLASSROOM DOOR</span><h3>Free to explore</h3></div><span className="catalog-group__aside">Start with a resource. Find your next step.</span></div>
              {renderCourseCards("Free resource")}
            </section>}
            {courseCount === 0 && <div className="no-results"><span className="no-results__icon"><Icon name="search" size={24} /></span><h3>No resources found just yet.</h3><p>Try a broader search, or clear the exam filter to see everything in the FREE classroom.</p><button className="button button--outline" type="button" onClick={() => { setSearchTerm(""); setSelectedTrack("All courses"); }}>Show all courses</button></div>}
          </div>
        </section>

        <section id="about-us" className="approach-section section-pad">
          <div className="site-container approach-layout">
            <div className="approach-visual" role="img" aria-label="Geography students looking out across a Himalayan river valley" />
            <div className="approach-copy">
              <span className="section-kicker">THE FREE WAY</span>
              <h2>Not more noise.<br /><em>A clearer way through.</em></h2>
              <p className="approach-copy__lead">Geography is more than lists on a page. It’s a way of seeing how places, processes and people connect.</p>
              <div className="approach-steps">
                <div className="approach-step"><span>01</span><div><h3>Understand the idea.</h3><p>Start with the “why” behind the process—not a definition to memorise.</p></div><Icon name="book" size={18} /></div>
                <div className="approach-step"><span>02</span><div><h3>See it on a map.</h3><p>Bring the idea to life in a place, a pattern or a landscape.</p></div><Icon name="map" size={18} /></div>
                <div className="approach-step"><span>03</span><div><h3>Practise with purpose.</h3><p>Use syllabus-focused questions to check what you understand.</p></div><Icon name="target" size={18} /></div>
              </div>
              <a className="text-link text-link--dark" href="#course-catalog">Find your learning path <Icon name="arrow-right" size={16} /></a>
            </div>
          </div>
        </section>

        <section className="journey-callout">
          <div className="site-container journey-callout__inner">
            <div className="journey-callout__compass" aria-hidden="true"><Icon name="compass" size={40} /></div>
            <div className="journey-callout__copy"><span className="section-kicker">YOUR NEXT STEP STARTS HERE</span><h2>Ready to find your direction?</h2><p>Tell us what you’re preparing for. We’ll point you to a free course to begin with.</p></div>
            <a className="button button--light" href="#contact">Talk to the FREE team <Icon name="arrow-up-right" size={17} /></a>
          </div>
        </section>

        <section id="contact" className="contact-section section-pad">
          <div className="site-container contact-layout">
            <div className="contact-copy">
              <span className="section-kicker">A HUMAN ON THE OTHER SIDE</span>
              <h2>Let’s talk about<br /><em>where you’re headed.</em></h2>
              <p>Questions about a course, the right exam track or where to start? Leave us a note — everything here is free, and we’ll get back to you by email.</p>
              <div className="contact-detail"><span className="contact-detail__icon"><Icon name="mail" size={19} /></span><div><strong>One message is all it takes.</strong><span>Tell us what you have in mind, and the FREE team will follow up.</span></div></div>
              <div className="contact-map-note"><span className="contact-map-note__lines" /><span>CURIOUS ABOUT THE WORLD.<br /><strong>HERE TO HELP YOU EXPLORE.</strong></span><Icon name="compass" size={32} /></div>
            </div>
            <div className="contact-form-card">
              <div className="contact-form-card__head"><div><span className="mini-label">CONTACT FREE</span><h3>Send us a note.</h3></div><span className="contact-form-card__mark"><Icon name="send" size={20} /></span></div>
              <form className="contact-form" onSubmit={handleInquirySubmit}>
                <div className="form-row">
                  <label className="form-field"><span>Your name <b>*</b></span><input name="name" autoComplete="name" value={formValues.name} onChange={(event) => updateForm("name", event.target.value)} placeholder="e.g. Aditi Sharma" required minLength={2} maxLength={120} /></label>
                  <label className="form-field"><span>Email address <b>*</b></span><input name="email" autoComplete="email" type="email" value={formValues.email} onChange={(event) => updateForm("email", event.target.value)} placeholder="you@example.com" required maxLength={254} /></label>
                </div>
                <div className="form-row">
                  <label className="form-field"><span>Phone <small>Optional</small></span><input name="phone" autoComplete="tel" type="tel" value={formValues.phone} onChange={(event) => updateForm("phone", event.target.value)} placeholder="Include country code" maxLength={30} /></label>
                  <label className="form-field"><span>I’m preparing for <b>*</b></span><select name="examFocus" value={formValues.examFocus} onChange={(event) => updateForm("examFocus", event.target.value)} required><option value="" disabled>Select an exam track</option><option>UGC NET Geography</option><option>UPSC CSE — Geography Optional</option><option>State SET Geography</option><option>Geography course enquiry</option><option>Free learning resources</option><option>Something else</option></select></label>
                </div>
                <label className="form-field form-field--full"><span>How can we help? <b>*</b></span><textarea name="message" value={formValues.message} onChange={(event) => updateForm("message", event.target.value)} placeholder="Tell us what you're looking for…" required minLength={10} maxLength={2000} rows={4} /></label>
                <div className="honeypot" aria-hidden="true"><label>Leave this empty<input name="website" tabIndex={-1} autoComplete="off" value={formValues.website} onChange={(event) => updateForm("website", event.target.value)} /></label></div>
                <div className="contact-form__submit">
                  <span className="form-privacy"><Icon name="shield" size={15} /> Your details are only used to reply to your enquiry.</span>
                  <button className="button button--primary" type="submit" disabled={formState === "sending"}>{formState === "sending" ? "Sending…" : "Send my enquiry"}<Icon name="arrow-right" size={17} /></button>
                </div>
                <div className={`form-feedback${formState === "success" ? " form-feedback--success" : formState === "error" ? " form-feedback--error" : ""}`} aria-live="polite" role={formState === "error" ? "alert" : "status"}>{formNotice && <><Icon name={formState === "error" ? "close" : "check-circle"} size={17} /> {formNotice}</>}</div>
              </form>
            </div>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="site-container footer-main">
          <div className="footer-brand"><BrandMark inverse /><p>Free, thoughtful geography learning<br />for the places you want to go.</p><span className="footer-brand__note"><Icon name="compass" size={15} /> FIND YOUR DIRECTION</span></div>
          <div className="footer-links"><span className="mini-label">EXPLORE</span><a href="#pyqs">Section-wise PYQs</a><a href="#full-courses">Full courses</a><a href="#mini-courses">Mini courses</a><a href="#free-courses">Free content</a></div>
          <div className="footer-links"><span className="mini-label">FREE GEOGRAPHY</span><a href="#about-us">Our approach</a><a href="#study-paths">Study paths</a><a href="#contact">Contact the team</a></div>
          <div className="footer-signoff"><span className="mini-label">A NOTE FOR THE JOURNEY</span><p>Small steps, considered maps, and a steady return to what matters.</p><a href="#hero" className="footer-top-link">Back to the top <Icon name="arrow-up-right" size={16} /></a></div>
        </div>
        <div className="site-container footer-bottom"><span>© {new Date().getFullYear()} FREE Geography. Learn with direction.</span><span>Made for curious minds, wherever they are.</span></div>
      </footer>

      <a className="floating-contact" href="#contact" aria-label="Ask the FREE team a question"><Icon name="mail" size={19} /><span>Talk to us</span></a>

      {notice && <div className="toast-notice" role="status"><Icon name="check-circle" size={18} />{notice}<button type="button" aria-label="Dismiss message" onClick={() => setNotice("")}><Icon name="close" size={15} /></button></div>}

      {modal && (
        <div className="dialog-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setModal(null); }}>
          <section className="dialog-card" role="dialog" aria-modal="true" aria-labelledby="dialog-title">
            <button className="dialog-close" type="button" aria-label="Close dialog" onClick={() => setModal(null)}><Icon name="close" size={20} /></button>
            {modal.type === "course" && <>
              <div className="dialog-course-image" style={{ backgroundImage: `url("${modal.course.image}")` }}><span className="course-card__pill">{modal.course.badge}</span></div>
              <div className="dialog-content">
                <div className="dialog-eyebrow">{modal.course.track} <span>·</span> {modal.course.kind}</div>
                <h2 id="dialog-title">{modal.course.title}</h2>
                <p className="dialog-lead">{modal.course.summary}</p>
                <div className="dialog-facts"><span><Icon name="clock" size={16} />{modal.course.duration}</span><span><Icon name="book" size={16} />{modal.course.lessons}</span></div>
                <h3>What you’ll explore</h3>
                <ul className="dialog-highlights">{modal.course.highlights.map((item) => <li key={item}><Icon name="check-circle" size={17} />{item}</li>)}</ul>
                <div className="dialog-actions"><button className="button button--primary" type="button" onClick={() => addToPlan(modal.course.id)}><Icon name="cart" size={17} /> Add to my plan</button><button className="button button--outline" type="button" onClick={() => startEnquiry(modal.course.track === "Free" ? "Free learning resources" : modal.course.track === "UPSC CSE" ? "UPSC CSE — Geography Optional" : modal.course.track === "State SET" ? "State SET Geography" : "UGC NET Geography")}>Ask about this course <Icon name="arrow-right" size={16} /></button></div>
              </div>
            </>}
            {modal.type === "offer" && <div className="dialog-content dialog-content--bundle">
              <div className={`bundle-modal-icon bundle-modal-icon--${modal.offer.accent}`}><Icon name={modal.offer.icon} size={26} /></div>
              <div className="dialog-eyebrow">{modal.offer.eyebrow} <span>·</span> BUILT AROUND YOUR EXAM</div>
              <h2 id="dialog-title">{modal.offer.title}</h2>
              <p className="dialog-lead">{modal.offer.description}</p>
              <h3>Included in this study path</h3>
              <div className="bundle-includes">{courses.filter((course) => modal.offer.courseIds.includes(course.id)).map((course) => <div className="bundle-include" key={course.id}><span className="bundle-include__icon"><Icon name={course.kind === "PYQ series" ? "layers" : "book"} size={16} /></span><span><strong>{course.title}</strong><small>{course.kind} · {course.subject}</small></span><Icon name="check" size={18} /></div>)}</div>
              <div className="dialog-actions"><button className="button button--primary" type="button" onClick={() => addOfferToPlan(modal.offer)}>Add this path to my plan <Icon name="arrow-right" size={17} /></button><button className="button button--outline" type="button" onClick={() => startEnquiry(modal.offer.examFocus)}>Ask about this path</button></div>
            </div>}
            {modal.type === "plan" && <div className="dialog-content dialog-content--plan">
              <div className="bundle-modal-icon"><Icon name="compass" size={26} /></div>
              <div className="dialog-eyebrow">YOUR FREE CLASSROOM</div>
              <h2 id="dialog-title">Your study plan<span className="plan-title-count">{plannedCourses.length}</span></h2>
              <p className="dialog-lead">Keep the courses and resources you’re considering together, then ask our team about next steps.</p>
              {plannedCourses.length === 0 ? <div className="plan-empty"><span className="plan-empty__icon"><Icon name="map" size={25} /></span><strong>Your plan starts with one good question.</strong><p>Explore the course library and add the courses or PYQ series that match your goals.</p><button type="button" className="text-link" onClick={() => { setModal(null); document.getElementById("course-catalog")?.scrollIntoView({ behavior: "smooth" }); }}>Browse the classroom <Icon name="arrow-right" size={16} /></button></div> : <><div className="plan-list">{plannedCourses.map((course) => <div className="plan-list__item" key={course.id}><span className="plan-list__icon"><Icon name={course.kind === "PYQ series" ? "layers" : course.kind === "Free resource" ? "play" : "book"} size={17} /></span><span><strong>{course.title}</strong><small>{course.kind} · {course.track}</small></span><button type="button" aria-label={`Remove ${course.title} from your plan`} onClick={() => removeFromPlan(course.id)}><Icon name="close" size={17} /></button></div>)}</div><div className="dialog-actions"><button className="button button--primary" type="button" onClick={() => startEnquiry("Geography course enquiry")}>Ask about my study plan <Icon name="arrow-right" size={17} /></button></div></>}
            </div>}
          </section>
        </div>
      )}
    </div>
  );
}
