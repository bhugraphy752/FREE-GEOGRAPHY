import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL;
const socialImage = siteUrl ? new URL("/images/free-geography-hero.jpg", siteUrl).toString() : undefined;

export const metadata: Metadata = {
  title: "FREE Geography — Geography learning, free for everyone",
  description:
    "Free geography courses, section-wise PYQs, map skills and study guidance for UGC NET, UPSC and State SET — open to everyone, always.",
  applicationName: "FREE Geography",
  keywords: [
    "FREE Geography",
    "free geography courses",
    "free UGC NET Geography preparation",
    "UPSC Geography Optional",
    "free geography PYQs",
    "map-based learning",
  ],
  openGraph: {
    title: "FREE Geography — Geography learning, free for everyone",
    description:
      "Free geography courses, section-wise PYQs and map-led learning for UGC NET, UPSC and State SET.",
    type: "website",
    ...(socialImage ? { images: [{ url: socialImage, width: 1536, height: 1024, alt: "Himalayan valley at sunrise" }] } : {}),
  },
  twitter: {
    card: "summary_large_image",
    title: "FREE Geography — Geography learning, free for everyone",
    description: "Free geography courses, PYQs and map-led learning, open to everyone.",
    ...(socialImage ? { images: [socialImage] } : {}),
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
