import { db } from "@/db";
import { freeInquiries } from "@/db/schema";

export const runtime = "nodejs";

export async function POST(request: Request) {
  let payload: unknown;

  try {
    payload = await request.json();
  } catch {
    return Response.json({ error: "Please send a valid enquiry." }, { status: 400 });
  }

  if (!payload || typeof payload !== "object" || Array.isArray(payload)) {
    return Response.json({ error: "Please send a valid enquiry." }, { status: 400 });
  }

  const values = payload as Record<string, unknown>;
  const name = typeof values.name === "string" ? values.name.trim() : "";
  const email = typeof values.email === "string" ? values.email.trim().toLowerCase() : "";
  const phone = typeof values.phone === "string" ? values.phone.trim() : "";
  const examFocus = typeof values.examFocus === "string" ? values.examFocus.trim() : "";
  const message = typeof values.message === "string" ? values.message.trim() : "";
  const website = typeof values.website === "string" ? values.website.trim() : "";

  // Honeypot: answer successfully without storing bot submissions.
  if (website) {
    return Response.json({ ok: true });
  }

  if (name.length < 2 || name.length > 120) {
    return Response.json({ error: "Please enter your name (at least 2 characters)." }, { status: 400 });
  }
  if (email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return Response.json({ error: "Please enter a valid email address." }, { status: 400 });
  }
  if (phone.length > 30 || (phone && phone.replace(/\D/g, "").length < 7)) {
    return Response.json({ error: "Please check your phone number." }, { status: 400 });
  }
  if (examFocus.length < 2 || examFocus.length > 120) {
    return Response.json({ error: "Please select the exam you are preparing for." }, { status: 400 });
  }
  if (message.length < 10 || message.length > 2000) {
    return Response.json({ error: "Please add a short message (10–2,000 characters)." }, { status: 400 });
  }

  try {
    await db.insert(freeInquiries).values({
      name,
      email,
      phone: phone || null,
      examFocus,
      message,
    });

    return Response.json({ ok: true, message: "Your message is on its way to the FREE team." }, { status: 201 });
  } catch (error) {
    console.error("Unable to save FREE enquiry", error);
    return Response.json(
      { error: "We could not save your message just now. Please try again shortly." },
      { status: 500 },
    );
  }
}
